<?php
/**
 * CompanySathi Blog API
 * Upload to your cPanel public_html directory.
 * Stores posts in blog-data.json (same directory).
 */

define('ADMIN_PIN_HASH', '79f06f8fde333461739f220090a23cb2a79f6d714bee100d0e4b4af249294619');
define('DATA_FILE', __DIR__ . '/blog-data.json');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Pin');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function verifyAdmin() {
    $pin = isset($_SERVER['HTTP_X_ADMIN_PIN']) ? $_SERVER['HTTP_X_ADMIN_PIN'] : '';
    if (hash('sha256', $pin) !== ADMIN_PIN_HASH) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}

function loadPosts() {
    if (!file_exists(DATA_FILE)) return [];
    $data = json_decode(file_get_contents(DATA_FILE), true);
    return isset($data['posts']) ? $data['posts'] : [];
}

function savePosts(array $posts) {
    file_put_contents(DATA_FILE, json_encode(
        ['posts' => array_values($posts)],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
    ));
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $posts = loadPosts();
    echo json_encode(['posts' => $posts, 'total' => count($posts)]);
    exit;
}

if ($method === 'POST') {
    verifyAdmin();
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) { http_response_code(400); echo json_encode(['error' => 'Invalid JSON']); exit; }
    $action = isset($body['action']) ? $body['action'] : '';

    switch ($action) {
        case 'create':
            $posts = loadPosts();
            $post = [
                'id'         => (string)(time() . rand(100, 999)),
                'title'      => trim($body['title'] ?? ''),
                'category'   => trim($body['category'] ?? ''),
                'date'       => trim($body['date'] ?? date('Y-m-d')),
                'coverImage' => trim($body['coverImage'] ?? ''),
                'content'    => $body['content'] ?? '',
            ];
            if (empty($post['title']) || empty($post['content'])) {
                http_response_code(400); echo json_encode(['error' => 'Title and content required']); exit;
            }
            array_unshift($posts, $post);
            savePosts($posts);
            echo json_encode(['success' => true, 'post' => $post]);
            break;

        case 'update':
            $posts = loadPosts();
            $id = (string)($body['id'] ?? '');
            $found = false;
            foreach ($posts as $i => $p) {
                if ((string)$p['id'] === $id) {
                    $posts[$i] = array_merge($p, [
                        'title'      => trim($body['title'] ?? $p['title']),
                        'category'   => trim($body['category'] ?? $p['category']),
                        'date'       => trim($body['date'] ?? $p['date']),
                        'coverImage' => trim($body['coverImage'] ?? $p['coverImage']),
                        'content'    => $body['content'] ?? $p['content'],
                    ]);
                    $found = true; $updated = $posts[$i]; break;
                }
            }
            if (!$found) { http_response_code(404); echo json_encode(['error' => 'Post not found']); exit; }
            savePosts($posts);
            echo json_encode(['success' => true, 'post' => $updated]);
            break;

        case 'delete':
            $posts = loadPosts();
            $id = (string)($body['id'] ?? '');
            $filtered = array_values(array_filter($posts, fn($p) => (string)$p['id'] !== $id));
            if (count($filtered) === count($posts)) {
                http_response_code(404); echo json_encode(['error' => 'Post not found']); exit;
            }
            savePosts($filtered);
            echo json_encode(['success' => true]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Unknown action']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>