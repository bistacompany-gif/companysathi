<?php
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';
$dataFile = __DIR__ . '/blog-data.json';
$post = null;
$allPosts = [];

if (file_exists($dataFile)) {
    $data = json_decode(file_get_contents($dataFile), true);
    $allPosts = $data['posts'] ?? [];
    foreach ($allPosts as $p) {
        if (($p['slug'] ?? '') === $slug) {
            $post = $p;
            break;
        }
    }
}

if (!$post) {
    http_response_code(404);
}

$pageTitle = $post ? htmlspecialchars($post['title']) . ' | CompanySathi Blog' : 'Post Not Found | CompanySathi Blog';
$metaDesc = $post ? htmlspecialchars($post['metaDescription'] ?? mb_substr(strip_tags($post['content']), 0, 160)) : 'Blog post not found.';
$ogImage = ($post && !empty($post['coverImage'])) ? htmlspecialchars($post['coverImage']) : 'https://companysathi.com/assets/hero-bg-BzLqKw6U.jpg';
$canonicalUrl = 'https://companysathi.com/blog/' . ($post ? htmlspecialchars($post['slug']) : '');
$postDate = $post ? date('F j, Y', strtotime($post['date'])) : '';
$postDateISO = $post ? date('c', strtotime($post['date'])) : '';
$readTime = $post ? ($post['readTime'] ?? max(1, ceil(str_word_count(strip_tags($post['content'])) / 200))) : 0;
$author = $post ? htmlspecialchars($post['author'] ?? 'CompanySathi Team') : '';
$category = $post ? htmlspecialchars($post['category']) : '';

/* Related posts (up to 3, excluding current) */
$related = [];
if ($post) {
    foreach ($allPosts as $rp) {
        if (($rp['id'] ?? '') !== ($post['id'] ?? '') && count($related) < 3) {
            $related[] = $rp;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $metaDesc ?>"/>
<meta name="author" content="<?= $author ?>"/>
<meta property="og:title" content="<?= $pageTitle ?>"/>
<meta property="og:description" content="<?= $metaDesc ?>"/>
<meta property="og:type" content="article"/>
<meta property="og:url" content="<?= $canonicalUrl ?>"/>
<meta property="og:image" content="<?= $ogImage ?>"/>
<meta property="article:published_time" content="<?= $postDateISO ?>"/>
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="<?= $pageTitle ?>"/>
<meta name="twitter:description" content="<?= $metaDesc ?>"/>
<meta name="twitter:image" content="<?= $ogImage ?>"/>
<link rel="canonical" href="<?= $canonicalUrl ?>"/>
<link rel="icon" type="image/png" href="/favicon.png"/>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php if ($post): ?>
<script type="application/ld+json">
<?= json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'BlogPosting',
    'headline' => $post['title'],
    'description' => $post['metaDescription'] ?? mb_substr(strip_tags($post['content']), 0, 160),
    'image' => !empty($post['coverImage']) ? $post['coverImage'] : 'https://companysathi.com/assets/hero-bg-BzLqKw6U.jpg',
    'datePublished' => date('c', strtotime($post['date'])),
    'author' => ['@type' => 'Person', 'name' => $post['author'] ?? 'CompanySathi Team'],
    'publisher' => [
        '@type' => 'Organization',
        'name' => 'CompanySathi',
        'url' => 'https://companysathi.com',
        'logo' => ['@type' => 'ImageObject', 'url' => 'https://companysathi.com/assets/logo-Cd0MwPDn.png']
    ],
    'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => $canonicalUrl],
    'url' => $canonicalUrl,
    'wordCount' => str_word_count(strip_tags($post['content']))
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
</script>
<?php endif; ?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}body{font-family:'DM Sans',sans-serif;color:#1a1a2e;background:#f8f6f0;overflow-x:hidden;line-height:1.6}
img{max-width:100%;display:block}a{text-decoration:none;color:inherit}button{cursor:pointer;border:none;background:none;font-family:inherit}ul{list-style:none}
:root{--navy:#0B1E3D;--navy-mid:#152a52;--navy-light:#1e3a6e;--gold:#C9A84C;--gold-light:#E2C472;--gold-pale:#f5e9c8;--cream:#f8f6f0;--cream-dark:#ede9df;--text:#1a1a2e;--text-light:#4a4a6a;--text-muted:#8888aa;--white:#fff;--radius:12px;--radius-lg:20px;--shadow:0 4px 24px rgba(11,30,61,.10);--shadow-lg:0 12px 40px rgba(11,30,61,.18);--shadow-gold:0 8px 32px rgba(201,168,76,.25)}
h1,h2,h3,h4{font-family:'Playfair Display',Georgia,serif;line-height:1.2}
p{font-size:1rem;line-height:1.75;color:var(--text-light)}
.container{max-width:1200px;margin:0 auto;padding:0 1.5rem}
/* READING PROGRESS BAR */
#readingProgress{position:fixed;top:0;left:0;height:3px;background:linear-gradient(90deg,var(--gold),var(--gold-light));z-index:2000;width:0;transition:width .1s linear}
/* NAV */
#navbar{position:fixed;top:3px;left:0;right:0;z-index:1000;background:rgba(11,30,61,.97);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 4px 24px rgba(11,30,61,.3);padding:.85rem 0}
.nav-inner{display:flex;align-items:center;justify-content:space-between}
.nav-logo{display:flex;align-items:center;gap:.75rem}
.nav-logo img{height:40px;width:auto;border-radius:8px}
.nav-logo-text{font-family:'Playfair Display',serif;font-size:1.4rem;font-weight:700;color:#fff;letter-spacing:-.01em}
.nav-logo-text span{color:var(--gold)}
.nav-links{display:flex;align-items:center;gap:.25rem}
.nav-links a{color:rgba(255,255,255,.85);font-size:.9rem;font-weight:500;padding:.5rem .9rem;border-radius:8px;transition:all .25s ease;position:relative}
.nav-links a::after{content:'';position:absolute;bottom:2px;left:50%;right:50%;height:2px;background:var(--gold);border-radius:2px;transition:all .3s ease}
.nav-links a:hover{color:#fff}.nav-links a:hover::after{left:10%;right:10%}
.nav-links a.active-link{color:#fff}.nav-links a.active-link::after{left:10%;right:10%}
.nav-cta{background:var(--gold)!important;color:var(--navy)!important;font-weight:700!important;padding:.55rem 1.25rem!important;border-radius:8px!important}
.nav-cta::after{display:none!important}.nav-cta:hover{background:var(--gold-light)!important;transform:translateY(-1px);box-shadow:var(--shadow-gold)}
.hamburger{display:none;flex-direction:column;gap:5px;padding:4px;cursor:pointer}
.hamburger span{display:block;width:24px;height:2px;background:#fff;border-radius:2px;transition:all .3s ease}
.hamburger.open span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.hamburger.open span:nth-child(2){opacity:0}
.hamburger.open span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}
.mobile-menu{display:none;position:fixed;top:67px;left:0;right:0;background:var(--navy);padding:1.5rem;flex-direction:column;gap:.5rem;z-index:999;border-top:1px solid rgba(255,255,255,.1)}
.mobile-menu.open{display:flex}
.mobile-menu a{color:rgba(255,255,255,.85);font-size:1rem;font-weight:500;padding:.75rem 1rem;border-radius:8px;transition:all .25s ease}
.mobile-menu a:hover{background:rgba(255,255,255,.08);color:#fff}
/* POST HERO */
.post-hero{position:relative;min-height:420px;display:flex;align-items:flex-end;overflow:hidden;margin-top:3px}
.post-hero-bg{position:absolute;inset:0;background-size:cover;background-position:center}
.post-hero-overlay{position:absolute;inset:0;background:linear-gradient(0deg,rgba(11,30,61,.95) 0%,rgba(11,30,61,.6) 40%,rgba(11,30,61,.3) 100%)}
.post-hero-placeholder{position:absolute;inset:0;background:linear-gradient(135deg,var(--navy) 0%,var(--navy-mid) 50%,var(--navy-light) 100%)}
.post-hero-placeholder::before{content:'';position:absolute;top:15%;right:8%;width:300px;height:300px;border:1px solid rgba(201,168,76,.1);border-radius:50%;animation:phFloat 14s ease-in-out infinite}
@keyframes phFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-15px)}}
.post-hero-content{position:relative;z-index:2;padding:2rem 0 3rem;width:100%}
.post-breadcrumb{display:flex;align-items:center;gap:.5rem;font-size:.82rem;color:rgba(255,255,255,.5);margin-bottom:1.25rem;flex-wrap:wrap}
.post-breadcrumb a{color:rgba(255,255,255,.6);transition:color .2s}.post-breadcrumb a:hover{color:var(--gold)}
.post-breadcrumb svg{opacity:.4;flex-shrink:0}
.post-breadcrumb .current{color:rgba(255,255,255,.8);max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.post-cat-badge{display:inline-block;background:var(--gold);color:var(--navy);font-size:.7rem;font-weight:700;padding:.35rem .85rem;border-radius:100px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:1rem}
.post-hero-title{color:#fff;font-size:clamp(1.8rem,4.5vw,2.8rem);font-weight:700;margin-bottom:1.25rem;max-width:800px;line-height:1.2}
.post-hero-meta{display:flex;align-items:center;flex-wrap:wrap;gap:1.5rem}
.post-meta-item{display:flex;align-items:center;gap:.4rem;color:rgba(255,255,255,.7);font-size:.88rem}
.post-meta-item svg{opacity:.6}
/* ARTICLE */
.article-wrapper{max-width:780px;margin:0 auto;padding:3rem 1.5rem 4rem}
.article-content{font-size:1.05rem;color:var(--text-light);line-height:1.85}
.article-content p{margin-bottom:1.25rem;color:var(--text-light)}
.article-content h2{font-family:'Playfair Display',serif;color:var(--navy);font-size:1.6rem;margin:2.5rem 0 .75rem;padding-top:1rem}
.article-content h3{font-family:'Playfair Display',serif;color:var(--navy);font-size:1.25rem;margin:2rem 0 .5rem}
.article-content ul,.article-content ol{padding-left:1.75rem;margin-bottom:1.25rem}
.article-content li{margin-bottom:.5rem;list-style:disc;color:var(--text-light)}
.article-content ol li{list-style:decimal}
.article-content strong{color:var(--text)}
.article-content a{color:var(--gold);text-decoration:underline;text-decoration-color:rgba(201,168,76,.3);transition:text-decoration-color .2s}
.article-content a:hover{text-decoration-color:var(--gold)}
.article-content blockquote{border-left:4px solid var(--gold);background:var(--gold-pale);padding:1.25rem 1.5rem;margin:1.5rem 0;border-radius:0 var(--radius) var(--radius) 0;font-style:italic;color:var(--text)}
.article-content img{border-radius:var(--radius);margin:1.5rem 0;box-shadow:var(--shadow)}
/* SHARE */
.share-section{border-top:1px solid var(--cream-dark);padding-top:2rem;margin-top:3rem}
.share-title{font-family:'Playfair Display',serif;font-size:1.15rem;color:var(--navy);margin-bottom:1rem}
.share-buttons{display:flex;gap:.6rem;flex-wrap:wrap}
.share-btn{display:inline-flex;align-items:center;gap:.5rem;padding:.6rem 1.1rem;border-radius:10px;font-size:.82rem;font-weight:600;color:#fff;transition:all .3s;cursor:pointer;border:none;font-family:'DM Sans',sans-serif}
.share-btn:hover{transform:translateY(-2px);box-shadow:var(--shadow)}
.share-btn.whatsapp{background:#25D366}.share-btn.facebook{background:#1877F2}.share-btn.linkedin{background:#0A66C2}
.share-btn.twitter{background:#1DA1F2}.share-btn.copy{background:var(--navy)}
.copied-tip{font-size:.75rem;color:var(--gold);font-weight:600;margin-left:.5rem;display:none}
/* AUTHOR BOX */
.author-box{background:#fff;border:1px solid var(--cream-dark);border-radius:var(--radius-lg);padding:1.75rem;margin-top:2.5rem;display:flex;align-items:center;gap:1.25rem}
.author-avatar{width:56px;height:56px;border-radius:50%;background:var(--gold-pale);display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;color:var(--gold);flex-shrink:0}
.author-info h4{font-family:'Playfair Display',serif;font-size:1.05rem;color:var(--navy);margin-bottom:.2rem}
.author-info p{font-size:.85rem;color:var(--text-muted);margin:0;line-height:1.5}
/* RELATED */
.related-section{padding:4rem 0 5rem}
.related-title-row{text-align:center;margin-bottom:2.5rem}
.related-label{display:inline-block;font-size:.75rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--gold);background:var(--gold-pale);padding:.4rem 1rem;border-radius:100px;margin-bottom:.75rem}
.related-heading{font-family:'Playfair Display',serif;font-size:1.8rem;color:var(--navy)}
.related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem}
.related-card{background:#fff;border-radius:var(--radius-lg);overflow:hidden;border:1px solid rgba(11,30,61,.06);transition:all .35s ease;text-decoration:none;display:flex;flex-direction:column}
.related-card:hover{transform:translateY(-6px);box-shadow:var(--shadow-lg)}
.related-cover{height:160px;position:relative;overflow:hidden;background:var(--navy)}
.related-cover img{width:100%;height:100%;object-fit:cover;transition:transform .5s}
.related-card:hover .related-cover img{transform:scale(1.06)}
.related-cover-ph{width:100%;height:100%;background:linear-gradient(135deg,var(--navy),var(--navy-light));display:flex;align-items:center;justify-content:center}
.related-cat{position:absolute;top:.7rem;left:.7rem;background:var(--gold);color:var(--navy);font-size:.62rem;font-weight:700;padding:.25rem .65rem;border-radius:100px;text-transform:uppercase;letter-spacing:.05em}
.related-body{padding:1.25rem;flex:1;display:flex;flex-direction:column}
.related-date{font-size:.72rem;color:var(--text-muted);margin-bottom:.4rem}
.related-card-title{font-family:'Playfair Display',serif;font-size:.95rem;font-weight:700;color:var(--navy);line-height:1.3;flex:1;transition:color .3s}
.related-card:hover .related-card-title{color:var(--gold)}
/* 404 */
.not-found{min-height:60vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:8rem 1.5rem 4rem}
.not-found-icon{width:100px;height:100px;background:var(--cream);border-radius:50%;display:flex;align-items:center;justify-content:center;margin-bottom:2rem}
.not-found h1{color:var(--navy);font-size:2rem;margin-bottom:.75rem}
.not-found p{color:var(--text-muted);font-size:1.05rem;margin-bottom:2rem;max-width:500px}
.btn-back{display:inline-flex;align-items:center;gap:.5rem;background:var(--gold);color:var(--navy);font-weight:700;font-size:1rem;padding:.85rem 2rem;border-radius:var(--radius);transition:all .3s;text-decoration:none;font-family:'DM Sans',sans-serif}
.btn-back:hover{background:var(--gold-light);transform:translateY(-2px);box-shadow:var(--shadow-gold)}
/* FOOTER */
footer{background:var(--navy);color:rgba(255,255,255,.7);padding:4rem 0 2rem}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1.5fr 1.5fr;gap:3rem;margin-bottom:3rem}
.footer-logo-text{font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;color:#fff;margin-bottom:1rem;display:block}
.footer-logo-text span{color:var(--gold)}
.footer-tagline{font-size:.875rem;line-height:1.7;color:rgba(255,255,255,.55)}
.footer-heading{font-family:'Playfair Display',serif;font-size:1rem;font-weight:600;color:#fff;margin-bottom:1rem}
.footer-links li{margin-bottom:.5rem}
.footer-links li a{font-size:.875rem;color:rgba(255,255,255,.55);transition:color .25s}
.footer-links li a:hover{color:var(--gold)}
.footer-ci{display:flex;gap:.6rem;align-items:flex-start;margin-bottom:.75rem;font-size:.85rem;color:rgba(255,255,255,.55)}
.footer-ci a{color:rgba(255,255,255,.55);transition:color .2s}.footer-ci a:hover{color:var(--gold)}
.footer-divider{border:none;border-top:1px solid rgba(255,255,255,.08);margin-bottom:1.5rem}
.footer-bottom{display:flex;justify-content:space-between;align-items:center;font-size:.82rem;color:rgba(255,255,255,.35)}
/* RESPONSIVE */
@media(max-width:1024px){.related-grid{grid-template-columns:repeat(2,1fr)}.footer-grid{grid-template-columns:1fr 1fr;gap:2rem}}
@media(max-width:768px){.nav-links{display:none}.hamburger{display:flex}.post-hero{min-height:340px}.post-hero-title{font-size:clamp(1.5rem,6vw,2.2rem)}.post-hero-meta{gap:1rem}.related-grid{grid-template-columns:1fr}.article-wrapper{padding:2rem 1rem 3rem}.footer-grid{grid-template-columns:1fr;gap:2rem}.footer-bottom{flex-direction:column;gap:.5rem;text-align:center}.author-box{flex-direction:column;text-align:center}}
@media(max-width:480px){.container{padding:0 1rem}.share-buttons{flex-direction:column}.share-btn{justify-content:center}}
</style>
</head>
<body>
<div id="readingProgress"></div>
<nav id="navbar">
  <div class="container nav-inner">
    <a href="/" class="nav-logo">
      <img src="https://companysathi.com/assets/logo-Cd0MwPDn.png" alt="CompanySathi Logo" onerror="this.style.display='none'"/>
      <span class="nav-logo-text">Company<span>Sathi</span></span>
    </a>
    <div class="nav-links">
      <a href="/">Home</a><a href="/#about">About</a><a href="/#experience">Experience</a>
      <a href="/#services">Services</a><a href="/blog" class="active-link">Blog</a><a href="/#contact" class="nav-cta">Contact Us</a>
    </div>
    <button class="hamburger" id="hamburger" aria-label="Toggle menu"><span></span><span></span><span></span></button>
  </div>
</nav>
<div class="mobile-menu" id="mobileMenu">
  <a href="/">Home</a><a href="/#about">About</a>
  <a href="/#experience">Experience</a><a href="/#services">Services</a>
  <a href="/blog">Blog</a><a href="/#contact">Contact Us</a>
</div>

<?php if (!$post): ?>
<!-- 404 -->
<div class="not-found">
  <div class="not-found-icon">
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
  </div>
  <h1>Post Not Found</h1>
  <p>The article you're looking for doesn't exist or may have been moved.</p>
  <a href="/blog" class="btn-back"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>Back to Blog</a>
</div>

<?php else: ?>
<!-- POST HERO -->
<section class="post-hero">
  <?php if (!empty($post['coverImage'])): ?>
  <div class="post-hero-bg" style="background-image:url('<?= htmlspecialchars($post['coverImage']) ?>')"></div>
  <div class="post-hero-overlay"></div>
  <?php else: ?>
  <div class="post-hero-placeholder"></div>
  <?php endif; ?>
  <div class="container post-hero-content">
    <div class="post-breadcrumb">
      <a href="/">Home</a>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m9 18 6-6-6-6"/></svg>
      <a href="/blog">Blog</a>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m9 18 6-6-6-6"/></svg>
      <span class="current"><?= htmlspecialchars($post['title']) ?></span>
    </div>
    <div class="post-cat-badge"><?= $category ?></div>
    <h1 class="post-hero-title"><?= htmlspecialchars($post['title']) ?></h1>
    <div class="post-hero-meta">
      <div class="post-meta-item">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <?= $author ?>
      </div>
      <div class="post-meta-item">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        <?= $postDate ?>
      </div>
      <div class="post-meta-item">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <?= $readTime ?> min read
      </div>
    </div>
  </div>
</section>

<!-- ARTICLE -->
<article class="article-wrapper">
  <div class="article-content" id="articleContent">
    <?= $post['content'] ?>
  </div>

  <!-- SHARE -->
  <div class="share-section">
    <h3 class="share-title">Share this article</h3>
    <div class="share-buttons">
      <button class="share-btn whatsapp" onclick="shareWhatsApp()"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.625.846 5.059 2.284 7.034L.789 23.492l4.623-1.467A11.933 11.933 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75c-2.09 0-4.03-.657-5.625-1.775l-.403-.24-2.744.871.87-2.684-.262-.418A9.719 9.719 0 012.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75z"/></svg>WhatsApp</button>
      <button class="share-btn facebook" onclick="shareFacebook()"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>Facebook</button>
      <button class="share-btn linkedin" onclick="shareLinkedIn()"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>LinkedIn</button>
      <button class="share-btn twitter" onclick="shareTwitter()"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>Twitter / X</button>
      <button class="share-btn copy" onclick="copyLink()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy Link<span class="copied-tip" id="copiedTip">Copied!</span></button>
    </div>
  </div>

  <!-- AUTHOR BOX -->
  <div class="author-box">
    <div class="author-avatar"><?= mb_substr($author, 0, 1) ?></div>
    <div class="author-info">
      <h4><?= $author ?></h4>
      <p>Expert team providing business registration, accounting, and legal compliance services across Nepal for over 20 years.</p>
    </div>
  </div>
</article>

<?php if (count($related) > 0): ?>
<!-- RELATED POSTS -->
<section class="related-section">
  <div class="container">
    <div class="related-title-row">
      <div class="related-label">Related Articles</div>
      <h2 class="related-heading">You May Also Like</h2>
    </div>
    <div class="related-grid">
      <?php foreach ($related as $rp):
        $rSlug = $rp['slug'] ?? '';
        $rDate = date('F j, Y', strtotime($rp['date']));
        $rCat = htmlspecialchars($rp['category']);
      ?>
      <a href="/blog/<?= htmlspecialchars($rSlug) ?>" class="related-card">
        <div class="related-cover">
          <?php if (!empty($rp['coverImage'])): ?>
          <img src="<?= htmlspecialchars($rp['coverImage']) ?>" alt="<?= htmlspecialchars($rp['title']) ?>" loading="lazy"/>
          <?php else: ?>
          <div class="related-cover-ph"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(201,168,76,.4)" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>
          <?php endif; ?>
          <span class="related-cat"><?= $rCat ?></span>
        </div>
        <div class="related-body">
          <div class="related-date"><?= $rDate ?></div>
          <div class="related-card-title"><?= htmlspecialchars($rp['title']) ?></div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>
<?php endif; ?>

<!-- FOOTER -->
<footer>
  <div class="container">
    <div class="footer-grid">
      <div><span class="footer-logo-text">Company<span>Sathi</span></span><p class="footer-tagline">Simplifying company registration and legal documentation in Nepal with over 20 years of expertise. Your trusted business partner.</p></div>
      <div><div class="footer-heading">Quick Links</div><ul class="footer-links"><li><a href="/">Home</a></li><li><a href="/#about">About</a></li><li><a href="/#services">Services</a></li><li><a href="/blog">Blog</a></li><li><a href="/#contact">Contact</a></li></ul></div>
      <div><div class="footer-heading">Our Services</div><ul class="footer-links"><li><a href="/#services">Company Registration</a></li><li><a href="/#services">Accounting &amp; Taxation</a></li><li><a href="/#services">Income Tax &amp; EXIM</a></li><li><a href="/#services">Trademark Registration</a></li><li><a href="/#services">Consult Professionals</a></li></ul></div>
      <div><div class="footer-heading">Contact Info</div>
        <div class="footer-ci"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C9A84C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>Baneshwor, Kathmandu, Nepal</div>
        <div class="footer-ci"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C9A84C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 10.5 19.79 19.79 0 0 1 1.59 1.87a2 2 0 0 1 2-2.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 6.91a16 16 0 0 0 6 6l.75-.75a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 14.92z"/></svg><a href="tel:+9779851235244">+977-9851235244</a></div>
        <div class="footer-ci"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C9A84C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg><a href="mailto:companysathi99@gmail.com">companysathi99@gmail.com</a></div>
      </div>
    </div>
    <hr class="footer-divider"/>
    <div class="footer-bottom">
      <span>&copy;2025 All rights reserved | CompanySathi</span>
      <span></span>
    </div>
  </div>
</footer>

<script>
/* NAV */
const ham=document.getElementById('hamburger');
const mob=document.getElementById('mobileMenu');
ham.addEventListener('click',()=>{ham.classList.toggle('open');mob.classList.toggle('open')});

/* READING PROGRESS */
const progressBar=document.getElementById('readingProgress');
const articleEl=document.getElementById('articleContent');
if(articleEl){
  window.addEventListener('scroll',()=>{
    const rect=articleEl.getBoundingClientRect();
    const articleTop=rect.top+window.scrollY;
    const articleHeight=articleEl.offsetHeight;
    const windowHeight=window.innerHeight;
    const scrolled=window.scrollY-articleTop+windowHeight;
    const total=articleHeight+windowHeight;
    const pct=Math.min(100,Math.max(0,(scrolled/total)*100));
    progressBar.style.width=pct+'%';
  });
}

/* SHARE FUNCTIONS */
const shareUrl=window.location.href;
const shareTitle=document.title;
function shareWhatsApp(){window.open('https://wa.me/?text='+encodeURIComponent(shareTitle+' '+shareUrl),'_blank')}
function shareFacebook(){window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(shareUrl),'_blank','width=600,height=400')}
function shareLinkedIn(){window.open('https://www.linkedin.com/sharing/share-offsite/?url='+encodeURIComponent(shareUrl),'_blank','width=600,height=400')}
function shareTwitter(){window.open('https://twitter.com/intent/tweet?url='+encodeURIComponent(shareUrl)+'&text='+encodeURIComponent(shareTitle),'_blank','width=600,height=400')}
function copyLink(){
  navigator.clipboard.writeText(shareUrl).then(()=>{
    const tip=document.getElementById('copiedTip');
    tip.style.display='inline';
    setTimeout(()=>{tip.style.display='none'},2000);
  });
}
</script>
</body>
</html>
