<?php
/**
 * CompanySathi Blog API
 * Upload to your cPanel public_html directory.
 * Stores posts in blog-data.json (same directory).
 */

define('ADMIN_PIN_HASH', '79f06f8fde333461739f220090a23cb2a79f6d714bee100d0e4b4af249294619');
define('DATA_FILE', __DIR__ . '/blog-data.json');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Pin');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function verifyAdmin() {
    $pin = isset($_SERVER['HTTP_X_ADMIN_PIN']) ? $_SERVER['HTTP_X_ADMIN_PIN'] : '';
    if (hash('sha256', $pin) !== ADMIN_PIN_HASH) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}

function loadPosts() {
    if (!file_exists(DATA_FILE)) return [];
    $data = json_decode(file_get_contents(DATA_FILE), true);
    return isset($data['posts']) ? $data['posts'] : [];
}

function savePosts(array $posts) {
    file_put_contents(DATA_FILE, json_encode(
        ['posts' => array_values($posts)],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
    ));
}

function generateSlug($title) {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
    $slug = preg_replace('/[\s-]+/', '-', $slug);
    $slug = trim($slug, '-');
    return $slug;
}

function calculateReadTime($content) {
    $text = strip_tags($content);
    $wordCount = str_word_count($text);
    return max(1, ceil($wordCount / 200));
}

function ensureFields(&$post) {
    if (empty($post['slug'])) {
        $post['slug'] = generateSlug($post['title']);
    }
    if (empty($post['author'])) {
        $post['author'] = 'CompanySathi Team';
    }
    if (empty($post['metaDescription'])) {
        $text = strip_tags($post['content'] ?? '');
        $post['metaDescription'] = mb_substr($text, 0, 160);
    }
    if (empty($post['readTime'])) {
        $post['readTime'] = calculateReadTime($post['content'] ?? '');
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $posts = loadPosts();

    /* Auto-migrate older posts that lack new fields */
    $modified = false;
    foreach ($posts as &$p) {
        if (empty($p['slug']) || empty($p['author']) || empty($p['readTime'])) {
            ensureFields($p);
            $modified = true;
        }
    }
    unset($p);
    if ($modified) savePosts($posts);

    /* Return single post by slug */
    if (isset($_GET['slug']) && $_GET['slug'] !== '') {
        $slug = $_GET['slug'];
        $found = null;
        foreach ($posts as $p) {
            if ($p['slug'] === $slug) { $found = $p; break; }
        }
        if ($found) {
            echo json_encode(['post' => $found]);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Post not found']);
        }
        exit;
    }

    echo json_encode(['posts' => $posts, 'total' => count($posts)]);
    exit;
}

if ($method === 'POST') {
    verifyAdmin();
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) { http_response_code(400); echo json_encode(['error' => 'Invalid JSON']); exit; }
    $action = isset($body['action']) ? $body['action'] : '';

    switch ($action) {
        case 'create':
            $posts = loadPosts();
            $title   = trim($body['title'] ?? '');
            $content = $body['content'] ?? '';
            $slug    = generateSlug($title);

            /* Ensure slug uniqueness */
            $base = $slug; $c = 1;
            while (array_filter($posts, fn($p) => ($p['slug'] ?? '') === $slug)) {
                $slug = $base . '-' . (++$c);
            }

            $post = [
                'id'              => (string)(time() . rand(100, 999)),
                'title'           => $title,
                'slug'            => $slug,
                'category'        => trim($body['category'] ?? ''),
                'date'            => trim($body['date'] ?? date('Y-m-d')),
                'coverImage'      => trim($body['coverImage'] ?? ''),
                'content'         => $content,
                'author'          => trim($body['author'] ?? 'CompanySathi Team'),
                'metaDescription' => trim($body['metaDescription'] ?? mb_substr(strip_tags($content), 0, 160)),
                'readTime'        => calculateReadTime($content),
            ];
            if (empty($post['title']) || empty($post['content'])) {
                http_response_code(400); echo json_encode(['error' => 'Title and content required']); exit;
            }
            array_unshift($posts, $post);
            savePosts($posts);
            echo json_encode(['success' => true, 'post' => $post]);
            break;

        case 'update':
            $posts = loadPosts();
            $id = (string)($body['id'] ?? '');
            $found = false;
            foreach ($posts as $i => $p) {
                if ((string)$p['id'] === $id) {
                    $newTitle   = trim($body['title'] ?? $p['title']);
                    $newContent = $body['content'] ?? $p['content'];
                    $newSlug    = isset($body['title']) ? generateSlug($newTitle) : ($p['slug'] ?? generateSlug($p['title']));

                    $base = $newSlug; $c = 1;
                    while (array_filter($posts, fn($pp) => ($pp['slug'] ?? '') === $newSlug && (string)$pp['id'] !== $id)) {
                        $newSlug = $base . '-' . (++$c);
                    }

                    $posts[$i] = array_merge($p, [
                        'title'           => $newTitle,
                        'slug'            => $newSlug,
                        'category'        => trim($body['category'] ?? $p['category']),
                        'date'            => trim($body['date'] ?? $p['date']),
                        'coverImage'      => trim($body['coverImage'] ?? $p['coverImage']),
                        'content'         => $newContent,
                        'author'          => trim($body['author'] ?? $p['author'] ?? 'CompanySathi Team'),
                        'metaDescription' => trim($body['metaDescription'] ?? $p['metaDescription'] ?? mb_substr(strip_tags($newContent), 0, 160)),
                        'readTime'        => calculateReadTime($newContent),
                    ]);
                    $found = true; $updated = $posts[$i]; break;
                }
            }
            if (!$found) { http_response_code(404); echo json_encode(['error' => 'Post not found']); exit; }
            savePosts($posts);
            echo json_encode(['success' => true, 'post' => $updated]);
            break;

        case 'delete':
            $posts = loadPosts();
            $id = (string)($body['id'] ?? '');
            $filtered = array_values(array_filter($posts, fn($p) => (string)$p['id'] !== $id));
            if (count($filtered) === count($posts)) {
                http_response_code(404); echo json_encode(['error' => 'Post not found']); exit;
            }
            savePosts($filtered);
            echo json_encode(['success' => true]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Unknown action']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>